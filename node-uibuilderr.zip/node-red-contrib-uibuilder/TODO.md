Moved to the [WIKI To Do page](https://github.com/TotallyInformation/node-red-contrib-uibuilder/wiki/To-Do).
