We welcome new pull requests to this repository but please follow the [contribution guidelines](https://github.com/TotallyInformation/node-red-contrib-uibuilder/blob/master/.github/CONTRIBUTING.md).

Please ensure that you are happy with the license for this repository and that all of your code meets the requirements for the license.

Please include the following information:

### A reference to any related issues in this repository


### A description of the changes proposed in the pull request and why


### Environment used for development and testing

Software       | Version
-------------- | -------
Node.JS        | 
npm            | 
Node-RED       | 
uibuilder node | 
uibuilderFE    | 
OS             | 
Browser        | 

