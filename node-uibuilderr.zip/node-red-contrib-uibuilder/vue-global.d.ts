// vue-global.d.ts
import _Vue = require('vue')

declare global {
  const Vue: typeof _Vue
}