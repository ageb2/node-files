# uibuilder Technical Documentation

uibuilder is a low-code solution for building data-driven web sites and web apps.

It works in conjunction with Node-RED.

All you need is a uibuilder node added to your flows. Select a suitable URL path and deploy.
Now you can send messages to your front end.

uibuilder comes with a default template set of front-end files that define your user interface (UI).
Open the uibuilder node and click on the button to open your web app in a new tab.

